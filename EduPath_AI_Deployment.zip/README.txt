# EduPath AI - Deployment Package

## Run locally
1. Install Python.
2. Open terminal in this folder.
3. Run:
   `pip install -r requirements.txt`
4. Run:
   `streamlit run app.py`

## Deploy on Streamlit Community Cloud
1. Create a GitHub repository.
2. Upload these three files:
   - app.py
   - student_performance_dataset.csv
   - requirements.txt
3. Open Streamlit Community Cloud.
4. Connect your GitHub account and select the repository.
5. Choose `app.py` as the main file.
6. Click Deploy.

The deployed app lets a normal user enter study hours, attendance, past exam score and related details, then shows Growth Score, Growth Level, Weak Area, Daily Recommendation and an ML-based Pass/Fail prediction.
